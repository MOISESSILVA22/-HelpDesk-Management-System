# 🎧 HelpDesk - Sistema de Chamados Full Stack

Sistema completo de gerenciamento de chamados com **Next.js 14 + Node.js + TypeScript + PostgreSQL + Prisma**.

---

## 📁 Estrutura do Projeto

```
helpdesk-system/
├── backend/        → API REST Node.js + Express + Prisma
└── frontend/       → Interface Next.js 14 App Router
```

---

## 🚀 Como Rodar

### Pré-requisitos
- Node.js 18+
- PostgreSQL rodando localmente (ou Docker)
- npm ou yarn

---

### 1. Backend

```bash
cd backend
npm install

# Copiar variáveis de ambiente
cp .env.example .env
# Edite o .env com sua DATABASE_URL e JWT_SECRET

# Gerar o Prisma Client
npm run db:generate

# Rodar as migrations
npm run db:migrate

# Popular o banco com dados de teste
npm run db:seed

# Iniciar em desenvolvimento
npm run dev
```

API disponível em: `http://localhost:3001`

---

### 2. Frontend

```bash
cd frontend
npm install

# Copiar variáveis de ambiente
cp .env.local.example .env.local

# Iniciar em desenvolvimento
npm run dev
```

App disponível em: `http://localhost:3000`

---

## 👤 Usuários de Teste (após seed)

| Role  | Email                  | Senha    |
|-------|------------------------|----------|
| Admin | admin@helpdesk.com     | admin123 |
| Agent | agente@helpdesk.com    | agent123 |
| User  | usuario@helpdesk.com   | user123  |

---

## 🏗️ Arquitetura Backend

```
src/
├── config/         → Prisma client, env validation
├── controllers/    → Lógica de cada rota
├── middlewares/    → Auth JWT, error handler
├── routes/         → Definição das rotas Express
├── types/          → Tipos TypeScript globais
├── utils/          → AppError, JWT helpers
└── server.ts       → Entry point
```

## 🎨 Arquitetura Frontend

```
src/
├── app/
│   ├── auth/       → Página de login
│   ├── dashboard/  → Dashboard com métricas
│   ├── tickets/    → Lista, detalhe, novo chamado
│   └── admin/      → Gestão de usuários
├── components/
│   ├── layout/     → Sidebar, DashboardLayout
│   └── ui/         → Badge, StatCard
├── hooks/          → useAuth, useTickets
├── lib/            → Axios instance, utils
└── types/          → Interfaces TypeScript
```

---

## 📡 Endpoints da API

| Método | Rota                        | Acesso            |
|--------|-----------------------------|-------------------|
| POST   | /api/auth/login             | Público           |
| POST   | /api/auth/register          | Público           |
| GET    | /api/auth/me                | Autenticado       |
| GET    | /api/tickets                | Autenticado       |
| POST   | /api/tickets                | USER/ADMIN        |
| GET    | /api/tickets/:id            | Autenticado       |
| PATCH  | /api/tickets/:id            | Autenticado       |
| DELETE | /api/tickets/:id            | ADMIN             |
| POST   | /api/tickets/:id/comments   | Autenticado       |
| GET    | /api/dashboard/stats        | Autenticado       |
| GET    | /api/users                  | ADMIN             |
| POST   | /api/users                  | ADMIN             |
| PATCH  | /api/users/:id              | ADMIN             |
| GET    | /api/categories             | Autenticado       |

---

## 🌐 Deploy

- **Frontend:** Vercel (`vercel deploy`)
- **Backend:** Render (`render.com`) ou Railway
- **Banco:** Supabase, Neon ou Railway PostgreSQL
