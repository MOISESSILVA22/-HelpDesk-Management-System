import { PrismaClient, Role, TicketStatus, TicketPriority } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Create categories
  const categories = await Promise.all([
    prisma.category.upsert({ where: { name: 'Infraestrutura' }, update: {}, create: { name: 'Infraestrutura' } }),
    prisma.category.upsert({ where: { name: 'Software' }, update: {}, create: { name: 'Software' } }),
    prisma.category.upsert({ where: { name: 'Acesso e Permissões' }, update: {}, create: { name: 'Acesso e Permissões' } }),
    prisma.category.upsert({ where: { name: 'Hardware' }, update: {}, create: { name: 'Hardware' } }),
  ]);

  const hash = (p: string) => bcrypt.hashSync(p, 10);

  // Create users
  const admin = await prisma.user.upsert({
    where: { email: 'admin@helpdesk.com' },
    update: {},
    create: { name: 'Administrador', email: 'admin@helpdesk.com', password: hash('admin123'), role: Role.ADMIN },
  });

  const agent = await prisma.user.upsert({
    where: { email: 'agente@helpdesk.com' },
    update: {},
    create: { name: 'Carlos Agente', email: 'agente@helpdesk.com', password: hash('agent123'), role: Role.AGENT },
  });

  const user = await prisma.user.upsert({
    where: { email: 'usuario@helpdesk.com' },
    update: {},
    create: { name: 'Maria Usuária', email: 'usuario@helpdesk.com', password: hash('user123'), role: Role.USER },
  });

  // Create sample tickets
  await prisma.ticket.createMany({
    skipDuplicates: true,
    data: [
      { title: 'Computador não liga', description: 'Meu computador não está ligando desde esta manhã.', status: TicketStatus.OPEN, priority: TicketPriority.HIGH, creatorId: user.id, categoryId: categories[3].id },
      { title: 'Sem acesso ao sistema ERP', description: 'Não consigo logar no sistema ERP após troca de senha.', status: TicketStatus.IN_PROGRESS, priority: TicketPriority.CRITICAL, creatorId: user.id, agentId: agent.id, categoryId: categories[2].id },
      { title: 'Impressora offline', description: 'A impressora do setor financeiro está aparecendo como offline.', status: TicketStatus.RESOLVED, priority: TicketPriority.MEDIUM, creatorId: user.id, agentId: agent.id, categoryId: categories[0].id },
      { title: 'Instalação do Microsoft Office', description: 'Preciso instalar o Office no notebook novo.', status: TicketStatus.OPEN, priority: TicketPriority.LOW, creatorId: user.id, categoryId: categories[1].id },
    ],
  });

  console.log('✅ Seed concluído!');
  console.log('👤 Admin: admin@helpdesk.com / admin123');
  console.log('🧑 Agente: agente@helpdesk.com / agent123');
  console.log('👦 Usuário: usuario@helpdesk.com / user123');
}

main().catch(console.error).finally(() => prisma.$disconnect());
