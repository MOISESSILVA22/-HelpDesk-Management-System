import { Router } from 'express';
import { authenticate, authorize } from '../middlewares/auth.middleware';
import { listTickets, getTicket, createTicket, updateTicket, deleteTicket, addComment } from '../controllers/ticket.controller';

const router = Router();

router.use(authenticate);

router.get('/', listTickets);
router.post('/', createTicket);
router.get('/:id', getTicket);
router.patch('/:id', updateTicket);
router.delete('/:id', authorize('ADMIN'), deleteTicket);
router.post('/:id/comments', addComment);

export default router;
