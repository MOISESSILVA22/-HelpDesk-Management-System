import { Router } from 'express';
import { authenticate, authorize } from '../middlewares/auth.middleware';
import { prisma } from '../config/prisma';

const router = Router();
router.use(authenticate);

router.get('/', async (_req, res, next) => {
  try {
    const categories = await prisma.category.findMany({ orderBy: { name: 'asc' } });
    res.json(categories);
  } catch (err) { next(err); }
});

router.post('/', authorize('ADMIN'), async (req, res, next) => {
  try {
    const { name } = req.body;
    const cat = await prisma.category.create({ data: { name } });
    res.status(201).json(cat);
  } catch (err) { next(err); }
});

export default router;
