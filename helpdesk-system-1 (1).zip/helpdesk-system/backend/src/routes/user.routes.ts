import { Router } from 'express';
import { authenticate, authorize } from '../middlewares/auth.middleware';
import { listUsers, createUser, updateUser } from '../controllers/user.controller';

const router = Router();

router.use(authenticate, authorize('ADMIN'));
router.get('/', listUsers);
router.post('/', createUser);
router.patch('/:id', updateUser);

export default router;
