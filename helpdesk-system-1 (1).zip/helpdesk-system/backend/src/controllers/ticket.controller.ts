import { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma';
import { AppError } from '../utils/AppError';
import { Role, TicketStatus, TicketPriority } from '@prisma/client';

const createSchema = z.object({
  title: z.string().min(5, 'Título muito curto'),
  description: z.string().min(10, 'Descrição muito curta'),
  priority: z.nativeEnum(TicketPriority).default(TicketPriority.MEDIUM),
  categoryId: z.string().uuid().optional(),
});

const updateSchema = z.object({
  title: z.string().min(5).optional(),
  description: z.string().min(10).optional(),
  status: z.nativeEnum(TicketStatus).optional(),
  priority: z.nativeEnum(TicketPriority).optional(),
  agentId: z.string().uuid().optional().nullable(),
  categoryId: z.string().uuid().optional().nullable(),
});

export const listTickets = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { status, priority, page = '1', limit = '10', search } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const where: Record<string, unknown> = {};
    if (req.user!.role === Role.USER) where.creatorId = req.user!.userId;
    if (status) where.status = status;
    if (priority) where.priority = priority;
    if (req.user!.role === Role.AGENT) where.agentId = req.user!.userId;
    if (search) where.title = { contains: String(search), mode: 'insensitive' };

    const [tickets, total] = await Promise.all([
      prisma.ticket.findMany({
        where,
        skip,
        take: Number(limit),
        orderBy: { createdAt: 'desc' },
        include: {
          creator: { select: { id: true, name: true, email: true } },
          agent: { select: { id: true, name: true, email: true } },
          category: true,
          _count: { select: { comments: true } },
        },
      }),
      prisma.ticket.count({ where }),
    ]);

    return res.json({ data: tickets, meta: { total, page: Number(page), limit: Number(limit), totalPages: Math.ceil(total / Number(limit)) } });
  } catch (err) {
    next(err);
  }
};

export const getTicket = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const ticket = await prisma.ticket.findUnique({
      where: { id: req.params.id },
      include: {
        creator: { select: { id: true, name: true, email: true } },
        agent: { select: { id: true, name: true, email: true } },
        category: true,
        comments: {
          where: req.user!.role === Role.USER ? { internal: false } : {},
          include: { author: { select: { id: true, name: true, role: true } } },
          orderBy: { createdAt: 'asc' },
        },
        history: {
          include: { user: { select: { id: true, name: true } } },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!ticket) throw new AppError('Chamado não encontrado', 404);
    if (req.user!.role === Role.USER && ticket.creatorId !== req.user!.userId) {
      throw new AppError('Acesso negado', 403);
    }

    return res.json(ticket);
  } catch (err) {
    next(err);
  }
};

export const createTicket = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = createSchema.parse(req.body);
    const ticket = await prisma.ticket.create({
      data: { ...data, creatorId: req.user!.userId },
      include: { creator: { select: { id: true, name: true } }, category: true },
    });
    return res.status(201).json(ticket);
  } catch (err) {
    next(err);
  }
};

export const updateTicket = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = updateSchema.parse(req.body);
    const existing = await prisma.ticket.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new AppError('Chamado não encontrado', 404);

    const isOwner = existing.creatorId === req.user!.userId;
    const isAgent = req.user!.role === Role.AGENT || req.user!.role === Role.ADMIN;
    if (!isOwner && !isAgent) throw new AppError('Acesso negado', 403);

    // Build history
    const historyEntries = Object.entries(data)
      .filter(([key, val]) => val !== undefined && existing[key as keyof typeof existing] !== val)
      .map(([field, newValue]) => ({
        field,
        oldValue: String(existing[field as keyof typeof existing] ?? ''),
        newValue: String(newValue),
        ticketId: existing.id,
        userId: req.user!.userId,
      }));

    const [ticket] = await prisma.$transaction([
      prisma.ticket.update({
        where: { id: req.params.id },
        data: { ...data, resolvedAt: data.status === TicketStatus.RESOLVED ? new Date() : undefined },
        include: { creator: { select: { id: true, name: true } }, agent: { select: { id: true, name: true } }, category: true },
      }),
      ...(historyEntries.length ? [prisma.ticketHistory.createMany({ data: historyEntries })] : []),
    ]);

    return res.json(ticket);
  } catch (err) {
    next(err);
  }
};

export const deleteTicket = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const ticket = await prisma.ticket.findUnique({ where: { id: req.params.id } });
    if (!ticket) throw new AppError('Chamado não encontrado', 404);
    await prisma.ticket.delete({ where: { id: req.params.id } });
    return res.status(204).send();
  } catch (err) {
    next(err);
  }
};

export const addComment = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { content, internal = false } = z.object({ content: z.string().min(1), internal: z.boolean().optional() }).parse(req.body);
    const ticket = await prisma.ticket.findUnique({ where: { id: req.params.id } });
    if (!ticket) throw new AppError('Chamado não encontrado', 404);

    if (req.user!.role === Role.USER && ticket.creatorId !== req.user!.userId) throw new AppError('Acesso negado', 403);
    if (internal && req.user!.role === Role.USER) throw new AppError('Usuários não podem criar comentários internos', 403);

    const comment = await prisma.comment.create({
      data: { content, internal, ticketId: req.params.id, authorId: req.user!.userId },
      include: { author: { select: { id: true, name: true, role: true } } },
    });

    return res.status(201).json(comment);
  } catch (err) {
    next(err);
  }
};
