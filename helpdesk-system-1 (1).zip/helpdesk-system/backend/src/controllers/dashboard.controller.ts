import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/prisma';
import { Role } from '@prisma/client';

export const getStats = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const where = req.user!.role === Role.USER ? { creatorId: req.user!.userId } : {};

    const [open, inProgress, resolved, closed, total, byPriority] = await Promise.all([
      prisma.ticket.count({ where: { ...where, status: 'OPEN' } }),
      prisma.ticket.count({ where: { ...where, status: 'IN_PROGRESS' } }),
      prisma.ticket.count({ where: { ...where, status: 'RESOLVED' } }),
      prisma.ticket.count({ where: { ...where, status: 'CLOSED' } }),
      prisma.ticket.count({ where }),
      prisma.ticket.groupBy({ by: ['priority'], where, _count: true }),
    ]);

    const recentTickets = await prisma.ticket.findMany({
      where,
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: { creator: { select: { name: true } }, category: true },
    });

    return res.json({
      stats: { open, inProgress, resolved, closed, total },
      byPriority,
      recentTickets,
    });
  } catch (err) {
    next(err);
  }
};
