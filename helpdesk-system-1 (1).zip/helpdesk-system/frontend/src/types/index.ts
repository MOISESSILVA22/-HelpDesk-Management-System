export type Role = 'ADMIN' | 'AGENT' | 'USER';
export type TicketStatus = 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED';
export type TicketPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  active?: boolean;
  createdAt?: string;
}

export interface Category {
  id: string;
  name: string;
}

export interface Comment {
  id: string;
  content: string;
  internal: boolean;
  createdAt: string;
  author: { id: string; name: string; role: Role };
}

export interface TicketHistory {
  id: string;
  field: string;
  oldValue?: string;
  newValue: string;
  createdAt: string;
  user: { id: string; name: string };
}

export interface Ticket {
  id: string;
  title: string;
  description: string;
  status: TicketStatus;
  priority: TicketPriority;
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
  creator: { id: string; name: string; email: string };
  agent?: { id: string; name: string; email: string } | null;
  category?: Category | null;
  comments?: Comment[];
  history?: TicketHistory[];
  _count?: { comments: number };
}

export interface PaginatedResponse<T> {
  data: T[];
  meta: { total: number; page: number; limit: number; totalPages: number };
}

export interface DashboardStats {
  stats: { open: number; inProgress: number; resolved: number; closed: number; total: number };
  byPriority: { priority: TicketPriority; _count: number }[];
  recentTickets: Ticket[];
}

export interface AuthResponse {
  token: string;
  user: User;
}
