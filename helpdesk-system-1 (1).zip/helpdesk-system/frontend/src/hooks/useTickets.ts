import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from '@/lib/api';
import { Ticket, PaginatedResponse } from '@/types';
import toast from 'react-hot-toast';

interface TicketFilters {
  page?: number;
  limit?: number;
  status?: string;
  priority?: string;
  search?: string;
}

export const useTickets = (filters: TicketFilters = {}) => {
  return useQuery<PaginatedResponse<Ticket>>({
    queryKey: ['tickets', filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([k, v]) => { if (v) params.set(k, String(v)); });
      const { data } = await api.get(`/tickets?${params}`);
      return data;
    },
  });
};

export const useTicket = (id: string) => {
  return useQuery<Ticket>({
    queryKey: ['ticket', id],
    queryFn: async () => { const { data } = await api.get(`/tickets/${id}`); return data; },
    enabled: !!id,
  });
};

export const useCreateTicket = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Partial<Ticket>) => api.post('/tickets', body).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['tickets'] }); toast.success('Chamado criado!'); },
    onError: () => toast.error('Erro ao criar chamado'),
  });
};

export const useUpdateTicket = (id: string) => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Partial<Ticket>) => api.patch(`/tickets/${id}`, body).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['tickets'] });
      qc.invalidateQueries({ queryKey: ['ticket', id] });
      toast.success('Chamado atualizado!');
    },
    onError: () => toast.error('Erro ao atualizar chamado'),
  });
};

export const useAddComment = (ticketId: string) => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: { content: string; internal?: boolean }) => api.post(`/tickets/${ticketId}/comments`, body).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['ticket', ticketId] }); toast.success('Comentário adicionado!'); },
    onError: () => toast.error('Erro ao comentar'),
  });
};
