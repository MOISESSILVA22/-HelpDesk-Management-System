'use client';
import { useState } from 'react';
import { useParams } from 'next/navigation';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { Badge } from '@/components/ui/Badge';
import { useTicket, useUpdateTicket, useAddComment } from '@/hooks/useTickets';
import { useAuth } from '@/hooks/useAuth';
import { statusLabel, statusColor, priorityLabel, priorityColor, formatDate } from '@/lib/utils';
import { ArrowLeft, Loader2, Send, Lock } from 'lucide-react';
import Link from 'next/link';
import { TicketStatus } from '@/types';

const STATUS_OPTIONS: TicketStatus[] = ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'];

export default function TicketDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { data: ticket, isLoading } = useTicket(id);
  const { mutate: updateTicket, isPending: updating } = useUpdateTicket(id);
  const { mutate: addComment, isPending: commenting } = useAddComment(id);
  const [comment, setComment] = useState('');
  const [internal, setInternal] = useState(false);

  const isStaff = user?.role === 'ADMIN' || user?.role === 'AGENT';

  const handleComment = () => {
    if (!comment.trim()) return;
    addComment({ content: comment, internal }, { onSuccess: () => setComment('') });
  };

  if (isLoading) return (
    <DashboardLayout>
      <div className="flex items-center justify-center h-64">
        <Loader2 size={28} className="animate-spin text-blue-600" />
      </div>
    </DashboardLayout>
  );

  if (!ticket) return <DashboardLayout><p className="text-gray-500">Chamado não encontrado.</p></DashboardLayout>;

  return (
    <DashboardLayout>
      <Link href="/tickets" className="flex items-center gap-2 text-gray-500 hover:text-gray-700 text-sm mb-6 transition-colors">
        <ArrowLeft size={16} /> Voltar para Chamados
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-start justify-between gap-4 mb-4">
              <h1 className="text-xl font-bold text-gray-900">{ticket.title}</h1>
              <div className="flex gap-2 shrink-0">
                <Badge className={priorityColor[ticket.priority]}>{priorityLabel[ticket.priority]}</Badge>
                <Badge className={statusColor[ticket.status]}>{statusLabel[ticket.status]}</Badge>
              </div>
            </div>
            <p className="text-gray-600 text-sm leading-relaxed whitespace-pre-wrap">{ticket.description}</p>
            <div className="mt-4 pt-4 border-t border-gray-100 flex items-center gap-4 text-xs text-gray-400">
              <span>Aberto por <strong className="text-gray-600">{ticket.creator.name}</strong></span>
              <span>{formatDate(ticket.createdAt)}</span>
              {ticket.category && <span className="bg-gray-100 px-2 py-0.5 rounded">{ticket.category.name}</span>}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="font-semibold text-gray-900 mb-4">Comentários ({ticket.comments?.length ?? 0})</h2>
            <div className="space-y-4 mb-6">
              {ticket.comments?.length === 0 && <p className="text-sm text-gray-400">Nenhum comentário ainda.</p>}
              {ticket.comments?.map(c => (
                <div key={c.id} className={`p-4 rounded-lg ${c.internal ? 'bg-yellow-50 border border-yellow-100' : 'bg-gray-50'}`}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm font-medium text-gray-800">{c.author.name}</span>
                    <span className="text-xs text-gray-400">{c.author.role}</span>
                    {c.internal && <span className="flex items-center gap-1 text-xs text-yellow-600"><Lock size={10} /> Interno</span>}
                    <span className="text-xs text-gray-400 ml-auto">{formatDate(c.createdAt)}</span>
                  </div>
                  <p className="text-sm text-gray-700">{c.content}</p>
                </div>
              ))}
            </div>
            <div className="space-y-3">
              <textarea
                value={comment}
                onChange={e => setComment(e.target.value)}
                placeholder="Adicione um comentário..."
                rows={3}
                className="w-full px-4 py-3 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
              />
              <div className="flex items-center justify-between">
                {isStaff && (
                  <label className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
                    <input type="checkbox" checked={internal} onChange={e => setInternal(e.target.checked)} className="rounded" />
                    Comentário interno
                  </label>
                )}
                <button
                  onClick={handleComment}
                  disabled={commenting || !comment.trim()}
                  className="ml-auto bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white px-4 py-2 rounded-lg text-sm font-medium transition flex items-center gap-2"
                >
                  {commenting ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
                  Comentar
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
            <h3 className="font-semibold text-gray-900 mb-4 text-sm">Detalhes</h3>
            <dl className="space-y-3 text-sm">
              <div className="flex justify-between">
                <dt className="text-gray-500">Agente</dt>
                <dd className="font-medium text-gray-800">{ticket.agent?.name ?? 'Não atribuído'}</dd>
              </div>
              {ticket.resolvedAt && (
                <div className="flex justify-between">
                  <dt className="text-gray-500">Resolvido em</dt>
                  <dd className="font-medium text-gray-800">{formatDate(ticket.resolvedAt)}</dd>
                </div>
              )}
            </dl>
          </div>

          {isStaff && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
              <h3 className="font-semibold text-gray-900 mb-4 text-sm">Alterar Status</h3>
              <div className="grid grid-cols-2 gap-2">
                {STATUS_OPTIONS.map(s => (
                  <button
                    key={s}
                    onClick={() => updateTicket({ status: s })}
                    disabled={updating || ticket.status === s}
                    className={`px-3 py-2 rounded-lg text-xs font-medium transition ${ticket.status === s ? 'bg-blue-600 text-white' : 'border border-gray-200 text-gray-600 hover:bg-gray-50'}`}
                  >
                    {statusLabel[s]}
                  </button>
                ))}
              </div>
            </div>
          )}

          {ticket.history && ticket.history.length > 0 && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
              <h3 className="font-semibold text-gray-900 mb-4 text-sm">Histórico</h3>
              <div className="space-y-3">
                {ticket.history.map(h => (
                  <div key={h.id} className="text-xs text-gray-500">
                    <span className="font-medium text-gray-700">{h.user.name}</span> alterou <strong>{h.field}</strong>
                    {h.oldValue && <> de <em>{h.oldValue}</em></>} para <em className="text-blue-600">{h.newValue}</em>
                    <div className="text-gray-400 mt-0.5">{formatDate(h.createdAt)}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
