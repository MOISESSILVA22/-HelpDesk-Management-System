'use client';
import DashboardLayout from '@/components/layout/DashboardLayout';
import { StatCard } from '@/components/ui/StatCard';
import { Badge } from '@/components/ui/Badge';
import { useQuery } from '@tanstack/react-query';
import api from '@/lib/api';
import { DashboardStats } from '@/types';
import { statusLabel, statusColor, priorityLabel, priorityColor, formatDate } from '@/lib/utils';
import { Ticket, Clock, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import Link from 'next/link';

export default function DashboardPage() {
  const { data, isLoading } = useQuery<DashboardStats>({
    queryKey: ['dashboard'],
    queryFn: () => api.get('/dashboard/stats').then(r => r.data),
  });

  if (isLoading) return (
    <DashboardLayout>
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    </DashboardLayout>
  );

  return (
    <DashboardLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 text-sm mt-1">Visão geral dos chamados</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Em Aberto" value={data?.stats.open ?? 0} icon={Ticket} color="text-blue-600" bgColor="bg-blue-50" />
        <StatCard title="Em Andamento" value={data?.stats.inProgress ?? 0} icon={Clock} color="text-yellow-600" bgColor="bg-yellow-50" />
        <StatCard title="Resolvidos" value={data?.stats.resolved ?? 0} icon={CheckCircle} color="text-green-600" bgColor="bg-green-50" />
        <StatCard title="Fechados" value={data?.stats.closed ?? 0} icon={XCircle} color="text-gray-600" bgColor="bg-gray-100" />
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <h2 className="font-semibold text-gray-900">Chamados Recentes</h2>
          <Link href="/tickets" className="text-blue-600 text-sm hover:underline">Ver todos</Link>
        </div>
        <div className="divide-y divide-gray-50">
          {data?.recentTickets.length === 0 && (
            <div className="p-8 text-center text-gray-400">
              <AlertTriangle size={32} className="mx-auto mb-2 opacity-40" />
              <p>Nenhum chamado ainda</p>
            </div>
          )}
          {data?.recentTickets.map(ticket => (
            <Link key={ticket.id} href={`/tickets/${ticket.id}`} className="flex items-center justify-between p-4 hover:bg-gray-50 transition-colors">
              <div className="min-w-0 flex-1">
                <p className="font-medium text-gray-900 truncate">{ticket.title}</p>
                <p className="text-xs text-gray-400 mt-0.5">{ticket.creator.name} · {formatDate(ticket.createdAt)}</p>
              </div>
              <div className="flex items-center gap-2 ml-4">
                <Badge className={priorityColor[ticket.priority]}>{priorityLabel[ticket.priority]}</Badge>
                <Badge className={statusColor[ticket.status]}>{statusLabel[ticket.status]}</Badge>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
